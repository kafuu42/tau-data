Context
This data was originally posted on my personal oneDrive account.

It represent fictitious/fake data on terminations. For each of 10 years it show employees that are active and those that terminated.

The intent is to see if individual terminations can be predicted from the data provided.

The thing to be predicted is status of active or terminated

Content
The data contains

employee id employee record date ( year of data) birth date hire date termination date age length of service city department job title store number gender termination reason termination type status year status business unit

These might be typical types of data in hris

Acknowledgements
None- its fake data


"Columns"
EmployeeID
recorddate_key
birthdate_key
orighiredate_key
terminationdate_key
age
length_of_service
city_name
department_name
job_title
store_name
gender_short
gender_full
termreason_desc
termtype_desc
STATUS_YEAR
STATUS
BUSINESS_UNIT