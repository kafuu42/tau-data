Description
Build the proposed optimized pricing model: Determine the largest or key value driver from the data Build price segments using product characteristics, distribution channel, behavior and demographic customer characteristics. Proposed new Pricing strategy bases of customer segmentation. Identify segments where we can lower the rates and as well as highlight segments where it is underpriced without impacting the profitability

Further detail inside the Excell Sheet