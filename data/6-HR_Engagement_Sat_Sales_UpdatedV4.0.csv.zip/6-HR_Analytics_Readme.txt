Context
We are building an HR analytics data set that can be used for building useful reports, understanding the difference between data and information, and multivariate analysis. The data set we are building is similar to that used in several academic reports and what may be found in ERP HR subsystems.

We will update the sample data set as we gain a better understanding of the data elements using the calculations that exist in scholarly journals. Specifically, we will use the correlation tables to rebuild the data sets.

Content
The fields represent a fictitious data set where a survey was taken and actual employee metrics exist for a particular organization. None of this data is real.

Acknowledgements
We wouldn't be here without the help of others. If you owe any attributions or thanks, include them here along with any citations of past research.

Prabhjot Singh contributed a portion of the data (the columns on the right before the survey data was added). https://www.kaggle.com/prabhjotindia https://www.kaggle.com/prabhjotindia/visualizing-employee-data/data

About this Dataset Why are our best and most experienced employees leaving prematurely? Have fun with this database and try to predict which valuable employees will leave next. Fields in the dataset include:

Satisfaction Level Last evaluation Number of projects Average monthly hours Time spent at the company Whether they have had a work accident Whether they have had a promotion in the last 5 years Departments Salary

Columns:
IDEmployee ID
NameEmployee Name
DepartmentThe functional department that the employee belongs to.
GEOThe working geography that the employee belongs to in a matrix organization.
RoleThe employee's position or title.
Rising_StarIndicates the level of promise or promote-ability the employee has.
Will_RelocateIs the employee willing to relocate?
CriticalIs the employee critical to the organization?
Trending PerfHow is the employee trending in performance this year?
Talent_LevelThis field represents a subjective level of management's view of the employee.
Validated_Talent_LevelThis field senior managements view of what the manager stated.
Percent_RemoteThe percentage of the employee's work that is done remotely.
EMP_Sat_OnPrem_1One indicator from a survey that was sent to employees by a third party. On prem (On premise) means that the employee maintains a high percentage of work on the corporation�s physical work locations.
EMP_Sat_OnPrem_2One indicator from a survey that was sent to employees by a third party. On prem (On premise) means that the employee maintains a high percentage of work on the corporation�s physical work locations.
EMP_Sat_OnPrem_3One indicator from a survey that was sent to employees by a third party. On prem (On premise) means that the employee maintains a high percentage of work on the corporation�s physical work locations.
EMP_Sat_OnPrem_4One indicator from a survey that was sent to employees by a third party. On prem (On premise) means that the employee maintains a high percentage of work on the corporation�s physical work locations.
EMP_Sat_OnPrem_5One indicator from a survey that was sent to employees by a third party. On prem (On premise) means that the employee maintains a high percentage of work on the corporation�s physical work locations.
EMP_Sat_Remote_1One indicator from a survey that was sent to employees by a third party. Remote (distance employee) means that the employee does a high percentage of work away from the corporation�s physical work locations.
EMP_Sat_Remote_2One indicator from a survey that was sent to employees by a third party. Remote (distance employee) means that the employee does a high percentage of work away from the corporation�s physical work locations.
EMP_Sat_Remote_3One indicator from a survey that was sent to employees by a third party. Remote (distance employee) means that the employee does a high percentage of work away from the corporation�s physical work locations.
EMP_Sat_Remote_4One indicator from a survey that was sent to employees by a third party. Remote (distance employee) means that the employee does a high percentage of work away from the corporation�s physical work locations.
EMP_Sat_Remote_5One indicator from a survey that was sent to employees by a third party. Remote (distance employee) means that the employee does a high percentage of work away from the corporation�s physical work locations.
EMP_Engagement_1One indicator from a survey that was sent to employees by a third party. Engagement represents the employee's feeling about how they feel about being engaged in company activities.
EMP_Engagement_2One indicator from a survey that was sent to employees by a third party. Engagement represents the employee's feeling about how they feel about being engaged in company activities.
EMP_Engagement_3One indicator from a survey that was sent to employees by a third party. Engagement represents the employee's feeling about how they feel about being engaged in company activities.
EMP_Engagement_4One indicator from a survey that was sent to employees by a third party. Engagement represents the employee's feeling about how they feel about being engaged in company activities.
EMP_Engagement_5One indicator from a survey that was sent to employees by a third party. Engagement represents the employee's feeling about how they feel about being engaged in company activities.
last_evaluationThe score on the last employee evaluation.
number_projectThe number of projects the employee works on throughout the year.
average_montly_hoursThe average number of hours the employee works.
time_spend_companyYears of service.
Work_accidentThe number of accidents the employee is involved in.
left_CompanyDid the employee leave the company?
CSR FactorIgnore
promotion_last_5yearsDid the employee get promoted in last 5 years?
salesIgnore
salaryRelative pay grade (low, medium, high) by role.
GenderGender or how the ?person identifies.
LinkedIn_HitsThe number of times employee visits LinkedIn networking sites.
Emp_Work_Status2One indicator from a survey that was sent to employees by a third party. Status represents how strongly employee feels about their status level in the organization.
Emp_Work_Status_3One indicator from a survey that was sent to employees by a third party. Status represents how strongly employee feels about their status level in the organization.
Emp_Work_Status_4One indicator from a survey that was sent to employees by a third party. Status represents how strongly employee feels about their status level in the organization.
Emp_Work_Status_5One indicator from a survey that was sent to employees by a third party. Status represents how strongly employee feels about their status level in the organization.?
Emp_IdentityHow the employee identifies themselves with the company.
Emp_RoleHow the employee identifies themselves with the importance of their role in the company.
Emp_PositionHow the employee identifies themselves with the importance of their position in the company.
Emp_TitleHow the employee feels about their title.
Women_LeaveWomen who left the company.
Men_LeaveMen who left the company.
Emp_Competitive_1One indicator from a survey that was sent to employees by a third party. How employee feels about the competitive nature of work in the organization.
Emp_Competitive_2One indicator from a survey that was sent to employees by a third party. How employee feels about the competitive nature of work in the organization.
Emp_Competitive_3One indicator from a survey that was sent to employees by a third party. How employee feels about the competitive nature of work in the organization.
Emp_Competitive_4One indicator from a survey that was sent to employees by a third party. How employee feels about the competitive nature of work in the organization.
Emp_Competitive_5One indicator from a survey that was sent to employees by a third party. How employee feels about the competitive nature of work in the organization.
Emp_Collaborative_1One indicator from a survey that was sent to employees by a third party. How employee feels about the collaborative nature of work in the organization.
Emp_Collaborative_2One indicator from a survey that was sent to employees by a third party. How employee feels about the collaborative nature of work in the organization.
Emp_Collaborative_3One indicator from a survey that was sent to employees by a third party. How employee feels about the collaborative nature of work in the organization.
Emp_Collaborative_4One indicator from a survey that was sent to employees by a third party. How employee feels about the collaborative nature of work in the organization.
Emp_Collaborative_5One indicator from a survey that was sent to employees by a third party. How employee feels about the collaborative nature of work in the organization.
Sensor_StepCountSentient devices are used to capture certain employee activities. In this case number of steps.
Sensor_Heartbeat(Average/Min)Sentient devices are used to capture certain employee activities. In this case heartbeat.
Sensor_Proximity(1-highest/10-lowest)Sentient devices are used to capture certain employee activities. In this case how close they are to their company laptop.