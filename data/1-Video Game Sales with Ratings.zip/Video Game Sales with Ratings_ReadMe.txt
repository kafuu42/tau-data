Context
Motivated by Gregory Smith's web scrape of VGChartz Video Games Sales, this data set simply extends the number of variables with another web scrape from Metacritic. Unfortunately, there are missing observations as Metacritic only covers a subset of the platforms. Also, a game may not have all the observations of the additional variables discussed below. Complete cases are ~ 6,900

Content

Alongside the fields: Name, Platform, Year_of_Release, Genre, Publisher, NA_Sales, EU_Sales, JP_Sales, Other_Sales, Global_Sales, we have:-

Critic_score - Aggregate score compiled by Metacritic staff
Critic_count - The number of critics used in coming up with the Critic_score
User_score - Score by Metacritic's subscribers
User_count - Number of users who gave the user_score
Developer - Party responsible for creating the game
Rating - The ESRB ratings

Acknowledgements
This repository, https://github.com/wtamu-cisresearch/scraper, after a few adjustments worked extremely well!

"Columns"

NameName of the game
PlatformConsole on which the game is running
Year_of_ReleaseYear of the game released
GenreGame's category
PublisherPublisher
NA_SalesGame sales in North America (in millions of units)
EU_SalesGame sales in the European Union (in millions of units)
JP_SalesGame sales in Japan (in millions of units)
Other_SalesGame sales in the rest of the world, i.e. Africa, Asia excluding Japan, Australia, Europe excluding the E.U. and South America (in millions of units)
Global_SalesTotal sales in the world (in millions of units)
Critic_ScoreAggregate score compiled by Metacritic staff
Critic_CountThe number of critics used in coming up with the Critic_score
User_ScoreScore by Metacritic's subscribers
User_CountNumber of users who gave the user_score
DeveloperParty responsible for creating the game
RatingThe ESRB ratings (E.g. Everyone, Teen, Adults Only..etc)